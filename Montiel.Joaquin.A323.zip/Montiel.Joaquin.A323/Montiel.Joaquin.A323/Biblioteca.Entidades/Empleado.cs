﻿using System.Data.Common;

namespace Biblioteca.Entidades
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        protected Empleado(string legajo,  string nombre, TimeSpan horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaIngreso = horaIngreso;
        }
        public TimeSpan HoraEgreso
        {
            
            get { return horaEgreso; }
            set { horaEgreso = ValidarHoraEgreso(value); }
        }

        public TimeSpan HoraIngreso
        {
            get { return horaIngreso; }
        }

        public string Legajo
        {
            get { return legajo; }
        }
        
        public string Nombre
        {
            get { return nombre; }
        }

        private TimeSpan ValidarHoraEgreso(TimeSpan horaEgreso)
        {
            if (horaEgreso > horaIngreso)
            {
                return horaEgreso;
            }
            return DateTime.Now.TimeOfDay;
        }

        protected double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours;
        }

        public static bool operator == (Empleado emp1, Empleado emp2)
        {
            return emp1 == emp2;
        }
        public static bool operator != (Empleado emp1, Empleado emp2)
        {
            return !(emp1 == emp2);
        }

        public virtual string EmitirFactura()
        {
            return $"Nombre: {this.Nombre} Importe a facturar: {Facturar()} ";
        }
    }
}
