﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Entidades
{
    public class Rac : Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private EGrupo grupo;
        static double valorHora;

        static Rac()
        {
            valorHora = 875.90F;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
        {
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo) :
            this(legajo, nombre, horaIngreso) 
        {
            this.grupo = 0;
        }

        public EGrupo Grupo
        {
            get { return grupo; }
        }

        public double ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public double CalcularBono()
        {
            switch (grupo)
            {
                case EGrupo.CALL_IN:
                    return 0.0;
                case EGrupo.CALL_OUT:
                    return 0.1;
                case EGrupo.RRSS:
                    return 0.2;
                default:
                    return 0.0;
            }
        }

        public double Facturar()
        {
            double totalHoras = (HoraEgreso - HoraIngreso).TotalHours;
            double bono = CalcularBono();
            return totalHoras * valorHora * (1 + bono);
        }

        public override string EmitirFactura()
        {
            double totalHorasFacturadas = Facturar();
            StringBuilder datosFacturacion = new StringBuilder();
            datosFacturacion.AppendLine("Factura de RAC");
            datosFacturacion.AppendLine($"Legajo: {Legajo}");
            datosFacturacion.AppendLine($"Nombre: {Nombre}");
            datosFacturacion.AppendLine($"Horas trabajadas: {(HoraEgreso - HoraIngreso).TotalHours}");
            datosFacturacion.AppendLine($"Valor Hora: {valorHora:C}");
            datosFacturacion.AppendLine($"Total Facturado: {totalHorasFacturadas:C}");
            return datosFacturacion.ToString();
        }

        public string ToString()
        {
            return $"{this.GetType().Name} - {grupo}- { legajo} - { nombre}";
        }


    }
}
