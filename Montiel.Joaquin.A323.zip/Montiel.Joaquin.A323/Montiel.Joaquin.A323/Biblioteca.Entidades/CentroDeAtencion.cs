﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Entidades
{
    public class CentroDeAtencion
    {
        private int cantRacPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public CentroDeAtencion(int cantRacPorSuper, string nombre)
        {
            this.cantRacPorSuper = cantRacPorSuper;
            this.nombre = nombre;
            empleados = new List<Empleado>();
            
        }

        public List<Empleado> Empleados
        {
            get { return empleados; }
        }

        public string Nombre
        {
            get { return nombre; }  
        }

        

        public static bool operator ==(CentroDeAtencion centro, Empleado empleado)
        {
            return centro.Empleados.Contains(empleado);
        }

        public static bool operator !=(CentroDeAtencion centro, Empleado empleado)
        {
            return !(centro == empleado);
        }
        private bool ValidaCantidadDeRacs()
        {
            int countRacs = Empleados.Count(e => e is Rac);
            int countSupervisores = Empleados.Count(e => e is Supervisor);

            return countSupervisores < (countRacs / cantRacPorSuper);
        }
        public static bool operator +(CentroDeAtencion centro, Empleado empleado)
        {
            if (!(centro == empleado))
            {
                if (empleado is Supervisor)
                {
                    if (centro.ValidaCantidadDeRacs())
                    {
                        centro.Empleados.Add(empleado);
                    }
                }
                else
                {
                    centro.Empleados.Add(empleado);
                }
            }
            return true;
        }

        public static string operator -(CentroDeAtencion centro, Empleado empleado)
        {
            if (centro.Empleados.Contains(empleado))
            {
                empleado.HoraEgreso = DateTime.Now.TimeOfDay;
                string factura = empleado.EmitirFactura();
                centro.Empleados.Remove(empleado);
                return factura;
            }
            else
            {
                return "Empleado no encontrado";
            }
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var empleado in Empleados)
            {
                sb.AppendLine($"{empleado.GetType().Name} - Legajo: {empleado.Legajo}, Nombre: {empleado.Nombre}");
            }
            return sb.ToString();
        }
    }
}
